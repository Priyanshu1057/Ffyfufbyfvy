from bot import Bot
import pyrogram.utils

pyrogram.utils.MIN_CHANNEL_ID = -1002508703787 -1002774088122 -1002783292697 -1002868541980

if __name__ == "__main__":
    Bot().run()
